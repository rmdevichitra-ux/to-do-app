# Simple To-Do App

A small static web app built with HTML, CSS, and vanilla JavaScript.
Add tasks, click to mark them done, and delete them. Tasks are saved in your browser's localStorage.

## Run locally
Open `index.html` in any browser.

## Files
- `index.html` – page structure
- `style.css` – styling
- `script.js` – app logic
