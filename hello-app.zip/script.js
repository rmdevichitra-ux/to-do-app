const input = document.getElementById("task");
const list = document.getElementById("list");
let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");

function save() { localStorage.setItem("tasks", JSON.stringify(tasks)); }

function render() {
  list.innerHTML = "";
  tasks.forEach((t, i) => {
    const li = document.createElement("li");
    if (t.done) li.classList.add("done");
    const span = document.createElement("span");
    span.textContent = t.text;
    span.onclick = () => { t.done = !t.done; save(); render(); };
    const del = document.createElement("button");
    del.textContent = "Delete";
    del.onclick = () => { tasks.splice(i, 1); save(); render(); };
    li.append(span, del);
    list.appendChild(li);
  });
}

function addTask() {
  const text = input.value.trim();
  if (!text) return;
  tasks.push({ text, done: false });
  input.value = "";
  save(); render();
}

document.getElementById("add").onclick = addTask;
input.addEventListener("keydown", e => { if (e.key === "Enter") addTask(); });
render();
